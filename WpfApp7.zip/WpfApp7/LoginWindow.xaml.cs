﻿using System.Windows;
using System.Windows.Input;

namespace WpfApp7
{
    public partial class LoginWindow : Window
    {

        private int _sessionAttempts = 0;
        private const int MaxSessionAttempts = 5;

        public LoginWindow()
        {
            InitializeComponent();

            this.KeyDown += LoginWindow_KeyDown;
        }

        private void LoginWindow_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                TryLogin();
            }
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            TryLogin();
        }

        private void TryLogin()
        {

            if (_sessionAttempts >= MaxSessionAttempts)
            {
                lblStatus.Text = "Слишком много попыток. Программа будет закрыта.";
                lblStatus.Foreground = System.Windows.Media.Brushes.Red;
                btnLogin.IsEnabled = false;


                var timer = new System.Windows.Threading.DispatcherTimer();
                timer.Interval = System.TimeSpan.FromSeconds(2);
                timer.Tick += (s, args) =>
                {
                    timer.Stop();
                    Application.Current.Shutdown();
                };
                timer.Start();
                return;
            }

            string login = txtLogin.Text.Trim();
            string password = txtPassword.Password;

            var user = UserService.TryLogin(login, password, out string errorMessage);

            if (user != null)
            {

                var mainWindow = new MainWindow(user);
                mainWindow.Show();
                this.Close();
            }
            else
            {

                _sessionAttempts++;
                lblStatus.Text = errorMessage;
                lblStatus.Foreground = System.Windows.Media.Brushes.Red;
                txtPassword.Clear();
                txtPassword.Focus();
            }
        }
    }
}