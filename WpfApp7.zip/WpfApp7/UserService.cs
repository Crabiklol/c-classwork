﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace WpfApp7
{
    public static class UserService
    {
        public static ObservableCollection<User> Users { get; }

        static UserService()
        {
            Users = new ObservableCollection<User>
            {
                new User
                {
                    Login = "admin",
                    Password = "admin123",
                    Role = "Администратор",
                    UserName = "Иван",
                    UserFamily = "Иванов",
                    UserPatronymic = "Иванович",
                    IsBlocked = false,
                    FailedAttempts = 0
                },
                new User
                {
                    Login = "manager",
                    Password = "manager123",
                    Role = "Менеджер",
                    UserName = "Петр",
                    UserFamily = "Петров",
                    UserPatronymic = "Петрович",
                    IsBlocked = false,
                    FailedAttempts = 0
                },
                new User
                {
                    Login = "guest",
                    Password = "guest123",
                    Role = "Гость",
                    UserName = "Сергей",
                    UserFamily = "Сидоров",
                    UserPatronymic = "Сергеевич",
                    IsBlocked = false,
                    FailedAttempts = 0
                }
            };
        }

        public static User TryLogin(string login, string password, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                errorMessage = "Введите логин и пароль.";
                return null;
            }

            var user = Users.FirstOrDefault(u => u.Login.Trim().ToLower() == login.Trim().ToLower());

            if (user == null)
            {
                errorMessage = "Неверный логин или пароль.";
                return null;
            }

            if (user.IsBlocked)
            {
                errorMessage = $"Пользователь '{user.Login}' заблокирован. Обратитесь к администратору.";
                return null;
            }

            if (user.Password != password)
            {
                user.FailedAttempts++;
                int remaining = 5 - user.FailedAttempts;

                if (user.FailedAttempts >= 5)
                {
                    user.IsBlocked = true;
                    errorMessage = $"Превышено число попыток. Пользователь '{user.Login}' заблокирован.";
                }
                else
                {
                    errorMessage = $"Неверный пароль. Осталось попыток: {remaining}.";
                }
                return null;
            }

            user.FailedAttempts = 0;
            return user;
        }
    }

    public class User : INotifyPropertyChanged
    {
        private string _login;
        private string _password;
        private string _role;
        private string _userName;
        private string _userFamily;
        private string _userPatronymic;
        private bool _isBlocked;
        private int _failedAttempts;

        public string Login
        {
            get => _login;
            set { _login = value; OnPropertyChanged(); }
        }

        public string Password
        {
            get => _password;
            set { _password = value; OnPropertyChanged(); }
        }

        public string Role
        {
            get => _role;
            set { _role = value; OnPropertyChanged(); }
        }

        public string UserName
        {
            get => _userName;
            set { _userName = value; OnPropertyChanged(); }
        }

        public string UserFamily
        {
            get => _userFamily;
            set { _userFamily = value; OnPropertyChanged(); }
        }

        public string UserPatronymic
        {
            get => _userPatronymic;
            set { _userPatronymic = value; OnPropertyChanged(); }
        }

        public bool IsBlocked
        {
            get => _isBlocked;
            set
            {
                _isBlocked = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(BlockedText));
            }
        }

        public int FailedAttempts
        {
            get => _failedAttempts;
            set { _failedAttempts = value; OnPropertyChanged(); }
        }

        public string BlockedText => IsBlocked ? "Да" : "Нет";

        public string FullName => $"{UserFamily} {UserName} {UserPatronymic}";

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}