﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;

namespace WpfApp7
{
    public static class CourseService
    {
        public static ObservableCollection<Course> Courses { get; }

        static CourseService()
        {
            Courses = new ObservableCollection<Course>
            {
                new Course
                {
                    Id = 1,
                    Name = "Основы C#",
                    Teacher = "Иванов И.И.",
                    Duration = 40,
                    Price = 15000
                },
                new Course
                {
                    Id = 2,
                    Name = "WPF для начинающих",
                    Teacher = "Петров П.П.",
                    Duration = 24,
                    Price = 8000
                },
                new Course
                {
                    Id = 3,
                    Name = "Базы данных SQL",
                    Teacher = "Сидоров С.С.",
                    Duration = 36,
                    Price = 12000
                },
                new Course
                {
                    Id = 4,
                    Name = "ASP.NET Core",
                    Teacher = "Кузнецов К.К.",
                    Duration = 50,
                    Price = 20000
                }
            };
        }

        public static int GetNextId()
        {
            return Courses.Count == 0 ? 1 : Courses.Max(c => c.Id) + 1;
        }
    }

    public class Course : INotifyPropertyChanged
    {
        private int _id;
        private string _name;
        private string _teacher;
        private int _duration;
        private decimal _price;

        public int Id
        {
            get => _id;
            set { _id = value; OnPropertyChanged(); }
        }

        public string Name
        {
            get => _name;
            set { _name = value; OnPropertyChanged(); }
        }

        public string Teacher
        {
            get => _teacher;
            set { _teacher = value; OnPropertyChanged(); }
        }

        public int Duration
        {
            get => _duration;
            set { _duration = value; OnPropertyChanged(); }
        }

        public decimal Price
        {
            get => _price;
            set { _price = value; OnPropertyChanged(); }
        }

        public string PriceText => $"{Price:N0} ₽";

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}