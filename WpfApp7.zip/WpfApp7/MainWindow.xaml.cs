﻿using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace WpfApp7
{
    public partial class MainWindow : Window
    {
        private Course _selectedCourse;
        private bool _isEditing = false;
        private User _currentUser;

        public MainWindow(User loggedInUser)
        {
            InitializeComponent();
            _currentUser = loggedInUser;
            InitializeData();
        }

        private void InitializeData()
        {
            // Отображаем информацию о вошедшем пользователе
            lblUserInfo.Text = $"Вы вошли как: {_currentUser.FullName} ({_currentUser.Role})";

            // Привязываем коллекцию курсов
            dgvCourses.ItemsSource = CourseService.Courses;

            // Разграничение прав доступа
            ApplyPermissions();

            lblStatus.Text = $"Каталог загружен. Курсов: {CourseService.Courses.Count}";
        }

        /// <summary>
        /// Применяет права доступа в зависимости от роли пользователя.
        /// Гости — только просмотр, администраторы и менеджеры — полный доступ.
        /// </summary>
        private void ApplyPermissions()
        {
            bool canEdit = _currentUser.Role == "Администратор"
                        || _currentUser.Role == "Менеджер";

            // Блокируем элементы управления для гостей
            txtEditName.IsEnabled = canEdit;
            txtEditTeacher.IsEnabled = canEdit;
            txtEditDuration.IsEnabled = canEdit;
            txtEditPrice.IsEnabled = canEdit;
            btnNew.IsEnabled = canEdit;
            btnSave.IsEnabled = canEdit;
            btnDelete.IsEnabled = canEdit;

            // Меняем заголовок формы
            if (!canEdit)
            {
                lblFormTitle.Text = "Просмотр информации (редактирование недоступно):";
                lblStatus.Text = "Режим только для чтения. Войдите как администратор или менеджер для редактирования.";
            }
        }

        private void dgvCourses_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (dgvCourses.SelectedItem is Course selectedCourse)
            {
                _selectedCourse = selectedCourse;
                _isEditing = true;

                txtEditName.Text = selectedCourse.Name;
                txtEditTeacher.Text = selectedCourse.Teacher;
                txtEditDuration.Text = selectedCourse.Duration.ToString();
                txtEditPrice.Text = selectedCourse.Price.ToString();

                lblStatus.Text = $"Выбран курс: {selectedCourse.Name}";
            }
        }

        private void btnNew_Click(object sender, RoutedEventArgs e)
        {
            _isEditing = false;
            _selectedCourse = null;
            ClearForm();
            lblStatus.Text = "Режим добавления нового курса.";
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            string name = txtEditName.Text.Trim();
            string teacher = txtEditTeacher.Text.Trim();
            string durationText = txtEditDuration.Text.Trim();
            string priceText = txtEditPrice.Text.Trim();

            // Валидация
            if (string.IsNullOrWhiteSpace(name))
            {
                lblStatus.Text = "Ошибка: Название курса не может быть пустым.";
                return;
            }
            if (string.IsNullOrWhiteSpace(teacher))
            {
                lblStatus.Text = "Ошибка: Укажите преподавателя.";
                return;
            }
            if (!int.TryParse(durationText, out int duration) || duration <= 0)
            {
                lblStatus.Text = "Ошибка: Длительность должна быть положительным числом.";
                return;
            }
            if (!decimal.TryParse(priceText, out decimal price) || price < 0)
            {
                lblStatus.Text = "Ошибка: Стоимость должна быть числом >= 0.";
                return;
            }

            if (_isEditing && _selectedCourse != null)
            {
                // Обновление существующего курса
                _selectedCourse.Name = name;
                _selectedCourse.Teacher = teacher;
                _selectedCourse.Duration = duration;
                _selectedCourse.Price = price;

                lblStatus.Text = $"Курс '{name}' успешно обновлён.";
            }
            else
            {
                // Добавление нового курса
                var newCourse = new Course
                {
                    Id = CourseService.GetNextId(),
                    Name = name,
                    Teacher = teacher,
                    Duration = duration,
                    Price = price
                };
                CourseService.Courses.Add(newCourse);
                lblStatus.Text = $"Курс '{name}' успешно добавлен (ID: {newCourse.Id}).";
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedCourse == null)
            {
                lblStatus.Text = "Сначала выберите курс в таблице для удаления.";
                return;
            }

            var result = MessageBox.Show(
                $"Удалить курс '{_selectedCourse.Name}'?",
                "Подтверждение удаления",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                CourseService.Courses.Remove(_selectedCourse);
                ClearForm();
                lblStatus.Text = $"Курс '{_selectedCourse.Name}' удалён.";
            }
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Выйти из системы?", "Выход",
                MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                var loginWindow = new LoginWindow();
                loginWindow.Show();
                this.Close();
            }
        }

        private void ClearForm()
        {
            txtEditName.Text = string.Empty;
            txtEditTeacher.Text = string.Empty;
            txtEditDuration.Text = string.Empty;
            txtEditPrice.Text = string.Empty;
            dgvCourses.SelectedItem = null;
        }
    }
}